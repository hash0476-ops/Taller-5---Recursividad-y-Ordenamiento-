/*
 * Taller 5 - Recursividad y Ordenamiento
 * Archivo unico: FrmOrdenamiento.java
 *   Compilar: javac FrmOrdenamiento.java
 *   Ejecutar: java FrmOrdenamiento
 * Datos.csv debe estar en la misma carpeta (si no, se abre un selector de archivos).
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

/**
 * Clase de utilidades: redimensionar arreglos y medir tiempos (cronómetro).
 */
class Util {

    private static long tiempoInicio;
    private static long tiempoFin;

    // Crea un arreglo nuevo (del mismo tipo) con el tamaño indicado y copia los datos
    public static Object redimensionar(Object arreglo, int nuevoTamano) {
        Class<?> tipo = arreglo.getClass().getComponentType();
        int tamanoActual = Array.getLength(arreglo);
        Object nuevo = Array.newInstance(tipo, nuevoTamano);
        System.arraycopy(arreglo, 0, nuevo, 0, Math.min(tamanoActual, nuevoTamano));
        return nuevo;
    }

    public static void iniciarCronometro() {
        tiempoInicio = System.nanoTime();
    }

    // Devuelve el tiempo transcurrido con formato HH:MM:SS.cc (cc = centésimas)
    public static String obtenerTextoTiempoCronometro() {
        tiempoFin = System.nanoTime();
        long centesimas = (tiempoFin - tiempoInicio) / 10_000_000L;
        long horas = centesimas / 360000;
        long minutos = (centesimas / 6000) % 60;
        long segundos = (centesimas / 100) % 60;
        long cent = centesimas % 100;
        return String.format("%02d:%02d:%02d.%02d", horas, minutos, segundos, cent);
    }
}

/**
 * Clase de utilidades para trabajar con archivos planos.
 */
class Archivo {

    // Abre un archivo de texto en UTF-8 (así se leen bien las Ñ y las tildes)
    public static BufferedReader abrirArchivo(String nombreArchivo) throws Exception {
        return new BufferedReader(
                new InputStreamReader(new FileInputStream(nombreArchivo), StandardCharsets.UTF_8));
    }
}

/**
 * Representa un documento de un cliente del banco.
 * Además contiene (como atributos y métodos estáticos) la lista de documentos
 * y todos los algoritmos de ordenamiento.
 */
class Documento {

    //********** Atributos de objeto **********
    private String nombre;
    private String apellido1;
    private String apellido2;
    private String tipoDocumento;
    // Se guarda ya armado para no concatenar textos millones de veces al ordenar
    private String nombreCompleto;

    public Documento() {
        this("", "", "", "");
    }

    public Documento(String apellido1, String apellido2, String nombre, String tipoDocumento) {
        this.nombre = nombre.trim();
        this.apellido1 = apellido1.trim();
        this.apellido2 = apellido2.trim();
        this.tipoDocumento = tipoDocumento.trim();
        // Si falta el segundo apellido no queda un doble espacio
        this.nombreCompleto = (this.apellido1 + " " + this.apellido2 + " " + this.nombre)
                .replaceAll("\\s+", " ").trim();
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    //********** Atributos y Métodos estáticos **********
    // Almacena la lista de documentos
    public static Documento[] documentos;

    // Método que agrega un documento a la lista
    public static void agregar(Documento d) {
        if (documentos == null) {
            documentos = new Documento[1];
        } else {
            documentos = (Documento[]) Util.redimensionar(documentos, documentos.length + 1);
        }
        documentos[documentos.length - 1] = d;
    }

    // Método que llena la lista con datos provenientes de un archivo.
    // Devuelve true si se pudo cargar.
    public static boolean obtenerLista(String nombreArchivo) {
        // Se usa un ArrayList mientras se lee: llamar agregar() 100.000 veces
        // copiaría el arreglo completo en cada llamada y sería muy lento.
        ArrayList<Documento> lista = new ArrayList<>();
        try (BufferedReader br = Archivo.abrirArchivo(nombreArchivo)) {
            String linea = br.readLine();       // encabezado (se descarta)
            linea = br.readLine();
            while (linea != null) {
                String[] textos = linea.split(";");
                if (textos.length >= 4) {
                    lista.add(new Documento(textos[0], textos[1], textos[2], textos[3]));
                }
                linea = br.readLine();
            }
        } catch (Exception ex) {
            System.out.println("Error leyendo el archivo: " + ex.getMessage());
            return false;
        }
        documentos = lista.toArray(new Documento[0]);
        return true;
    }

    // Método que despliega en un JTable la lista de documentos cargados
    public static void mostrarLista(JTable tbl) {
        String[] encabezados = new String[]{"Nombre", "Tipo Documento"};
        String[][] datos = new String[documentos.length][encabezados.length];
        for (int i = 0; i < documentos.length; i++) {
            datos[i][0] = documentos[i].getNombreCompleto();
            datos[i][1] = documentos[i].getTipoDocumento();
        }
        tbl.setModel(new DefaultTableModel(datos, encabezados) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        });
    }

    // Método para intercambiar elementos
    private static void intercambiar(int origen, int destino) {
        Documento t = documentos[origen];
        documentos[origen] = documentos[destino];
        documentos[destino] = t;
    }

    // Verifica si el documento dI es mayor que dJ según el criterio de ordenación
    // criterio 0: Nombre completo y luego Tipo de documento
    // criterio 1: Tipo de documento y luego Nombre completo
    private static boolean esMayor(Documento dI, Documento dJ, int criterio) {
        int porNombre = dI.getNombreCompleto().compareTo(dJ.getNombreCompleto());
        int porTipo = dI.getTipoDocumento().compareTo(dJ.getTipoDocumento());
        if (criterio == 0) {
            return porNombre > 0 || (porNombre == 0 && porTipo > 0);
        } else {
            return porTipo > 0 || (porTipo == 0 && porNombre > 0);
        }
    }

    //******************** Ordenamiento BURBUJA (no recursivo)
    // Se compara cada posición con las restantes, tal como se explica en el taller
    public static String ordenarBurbuja(int criterio) {
        Util.iniciarCronometro();
        for (int i = 0; i < documentos.length - 1; i++) {
            for (int j = i + 1; j < documentos.length; j++) {
                if (esMayor(documentos[i], documentos[j], criterio)) {
                    intercambiar(i, j);
                }
            }
        }
        return Util.obtenerTextoTiempoCronometro();
    }

    //******************** Ordenamiento RÁPIDO (recursivo)
    public static String ordenarRapido(int criterio) {
        Util.iniciarCronometro();
        _ordenarRapido(0, documentos.length - 1, criterio);
        return Util.obtenerTextoTiempoCronometro();
    }

    // Método recursivo. Los índices inicio y fin indican sobre qué parte de la lista opera
    private static void _ordenarRapido(int inicio, int fin, int criterio) {
        // Punto de finalización (caso base)
        if (inicio >= fin) {
            return;
        }
        // Caso recursivo
        int posicionPivote = ubicarPivote(inicio, fin, criterio);
        _ordenarRapido(inicio, posicionPivote - 1, criterio);  // ordenar los menores
        _ordenarRapido(posicionPivote + 1, fin, criterio);     // ordenar los mayores
    }

    // Busca la posición del pivote: antes quedan los menores y después los mayores
    private static int ubicarPivote(int inicio, int fin, int criterio) {
        // Se toma el elemento del medio como pivote (y se lleva al inicio).
        // Si siempre se usara el primero, una lista que ya está ordenada
        // generaría ~100.000 llamadas recursivas anidadas y se desbordaría la pila.
        intercambiar(inicio, (inicio + fin) / 2);

        Documento dPivote = documentos[inicio];
        int posicionPivote = inicio;
        for (int i = inicio + 1; i < fin + 1; i++) {
            if (esMayor(dPivote, documentos[i], criterio)) {
                posicionPivote++;
                if (i != posicionPivote) {
                    intercambiar(i, posicionPivote);
                }
            }
        }
        // Pone el pivote al final de los menores
        if (inicio != posicionPivote) {
            intercambiar(inicio, posicionPivote);
        }
        return posicionPivote;
    }

    //******************** Ordenamiento por INSERCIÓN (no recursivo)
    // Cada elemento se "inserta" en el lugar que le corresponde dentro de la parte ya ordenada
    public static String ordenarInsercion(int criterio) {
        Util.iniciarCronometro();
        for (int i = 1; i < documentos.length; i++) {
            Documento actual = documentos[i];
            int j = i - 1;
            // Se corren hacia la derecha los elementos mayores que el actual
            while (j >= 0 && esMayor(documentos[j], actual, criterio)) {
                documentos[j + 1] = documentos[j];
                j--;
            }
            documentos[j + 1] = actual;
        }
        return Util.obtenerTextoTiempoCronometro();
    }

    //******************** Ordenamiento por SELECCIÓN (no recursivo)
    // En cada vuelta se busca el menor de los que faltan y se ubica en su posición
    public static String ordenarSeleccion(int criterio) {
        Util.iniciarCronometro();
        for (int i = 0; i < documentos.length - 1; i++) {
            int posMenor = i;
            for (int j = i + 1; j < documentos.length; j++) {
                if (esMayor(documentos[posMenor], documentos[j], criterio)) {
                    posMenor = j;
                }
            }
            if (posMenor != i) {
                intercambiar(i, posMenor);
            }
        }
        return Util.obtenerTextoTiempoCronometro();
    }

    //******************** Ordenamiento por MEZCLA - MergeSort (recursivo)
    public static String ordenarMezcla(int criterio) {
        Util.iniciarCronometro();
        // Arreglo auxiliar que se crea una sola vez y se reutiliza en las mezclas
        Documento[] auxiliar = new Documento[documentos.length];
        _ordenarMezcla(auxiliar, 0, documentos.length - 1, criterio);
        return Util.obtenerTextoTiempoCronometro();
    }

    private static void _ordenarMezcla(Documento[] auxiliar, int inicio, int fin, int criterio) {
        // Caso base: una sola posición ya está ordenada
        if (inicio >= fin) {
            return;
        }
        int medio = (inicio + fin) / 2;
        _ordenarMezcla(auxiliar, inicio, medio, criterio);     // ordenar mitad izquierda
        _ordenarMezcla(auxiliar, medio + 1, fin, criterio);    // ordenar mitad derecha
        mezclar(auxiliar, inicio, medio, fin, criterio);       // unir las dos mitades
    }

    // Une dos mitades ya ordenadas: [inicio..medio] y [medio+1..fin]
    private static void mezclar(Documento[] auxiliar, int inicio, int medio, int fin, int criterio) {
        // Copia el segmento al auxiliar
        for (int k = inicio; k <= fin; k++) {
            auxiliar[k] = documentos[k];
        }
        int i = inicio;      // recorre la mitad izquierda
        int j = medio + 1;   // recorre la mitad derecha
        for (int k = inicio; k <= fin; k++) {
            if (i > medio) {                 // se acabó la izquierda
                documentos[k] = auxiliar[j++];
            } else if (j > fin) {            // se acabó la derecha
                documentos[k] = auxiliar[i++];
            } else if (esMayor(auxiliar[i], auxiliar[j], criterio)) {
                documentos[k] = auxiliar[j++];   // gana el de la derecha
            } else {
                documentos[k] = auxiliar[i++];   // gana el de la izquierda
            }
        }
    }
}

/**
 * Interfaz gráfica del aplicativo de ordenamiento.
 */
public class FrmOrdenamiento extends JFrame {

    private JButton btnBurbuja, btnRapido, btnInsercion, btnSeleccion, btnMezcla, btnRecargar;
    private JComboBox<String> cmbCriterio;
    private JTextField txtTiempo;
    private JTable tblDatos;
    private String nombreArchivo;

    public FrmOrdenamiento() {
        crearComponentes();
        cargarDatos();
    }

    private void crearComponentes() {
        setTitle("Ordenamiento de documentos - Entidad bancaria");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);

        btnBurbuja = new JButton("Burbuja");
        btnRapido = new JButton("Rápido");
        btnInsercion = new JButton("Inserción");
        btnSeleccion = new JButton("Selección");
        btnMezcla = new JButton("Mezcla");
        btnRecargar = new JButton("Recargar datos");

        cmbCriterio = new JComboBox<>(new String[]{"Nombre - Documento", "Documento - Nombre"});
        txtTiempo = new JTextField(10);
        txtTiempo.setEditable(false);
        txtTiempo.setHorizontalAlignment(JTextField.CENTER);

        JPanel pnlSuperior = new JPanel(new FlowLayout(FlowLayout.LEFT));
        pnlSuperior.add(btnBurbuja);
        pnlSuperior.add(btnRapido);
        pnlSuperior.add(btnInsercion);
        pnlSuperior.add(btnSeleccion);
        pnlSuperior.add(btnMezcla);
        pnlSuperior.add(new JLabel("Criterio:"));
        pnlSuperior.add(cmbCriterio);
        pnlSuperior.add(new JLabel("Tiempo:"));
        pnlSuperior.add(txtTiempo);
        pnlSuperior.add(btnRecargar);

        tblDatos = new JTable();

        setLayout(new BorderLayout());
        add(pnlSuperior, BorderLayout.NORTH);
        add(new JScrollPane(tblDatos), BorderLayout.CENTER);

        // Eventos de los botones
        btnBurbuja.addActionListener(e -> ordenar("BURBUJA"));
        btnRapido.addActionListener(e -> ordenar("RAPIDO"));
        btnInsercion.addActionListener(e -> ordenar("INSERCION"));
        btnSeleccion.addActionListener(e -> ordenar("SELECCION"));
        btnMezcla.addActionListener(e -> ordenar("MEZCLA"));
        btnRecargar.addActionListener(e -> cargarDatos());
    }

    // Busca el archivo Datos.csv; si no lo encuentra, deja que el usuario lo elija
    private void cargarDatos() {
        if (nombreArchivo == null) {
            String[] posibles = {
                System.getProperty("user.dir") + "/Datos.csv",
                System.getProperty("user.dir") + "/src/Datos/Datos.csv"
            };
            for (String ruta : posibles) {
                if (new File(ruta).exists()) {
                    nombreArchivo = ruta;
                    break;
                }
            }
        }
        if (nombreArchivo == null) {
            JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
            fc.setDialogTitle("Seleccione el archivo Datos.csv");
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                nombreArchivo = fc.getSelectedFile().getAbsolutePath();
            } else {
                return;
            }
        }
        if (Documento.obtenerLista(nombreArchivo)) {
            Documento.mostrarLista(tblDatos);
            txtTiempo.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo leer el archivo:\n" + nombreArchivo);
            nombreArchivo = null;
        }
    }

    private void habilitarBotones(boolean estado) {
        btnBurbuja.setEnabled(estado);
        btnRapido.setEnabled(estado);
        btnInsercion.setEnabled(estado);
        btnSeleccion.setEnabled(estado);
        btnMezcla.setEnabled(estado);
        btnRecargar.setEnabled(estado);
        cmbCriterio.setEnabled(estado);
    }

    // Ejecuta el algoritmo elegido en un hilo aparte para que la ventana no se congele
    // (la burbuja con 100.000 datos puede tardar varios minutos)
    private void ordenar(String algoritmo) {
        if (Documento.documentos == null || cmbCriterio.getSelectedIndex() < 0) {
            return;
        }
        final int criterio = cmbCriterio.getSelectedIndex();
        habilitarBotones(false);
        txtTiempo.setText("Ordenando...");

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                switch (algoritmo) {
                    case "BURBUJA":   return Documento.ordenarBurbuja(criterio);
                    case "RAPIDO":    return Documento.ordenarRapido(criterio);
                    case "INSERCION": return Documento.ordenarInsercion(criterio);
                    case "SELECCION": return Documento.ordenarSeleccion(criterio);
                    default:          return Documento.ordenarMezcla(criterio);
                }
            }

            @Override
            protected void done() {
                try {
                    txtTiempo.setText(get());
                    Documento.mostrarLista(tblDatos);
                } catch (Exception ex) {
                    txtTiempo.setText("Error");
                    JOptionPane.showMessageDialog(FrmOrdenamiento.this, "Error al ordenar: " + ex.getCause());
                }
                habilitarBotones(true);
            }
        }.execute();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FrmOrdenamiento().setVisible(true));
    }
}
